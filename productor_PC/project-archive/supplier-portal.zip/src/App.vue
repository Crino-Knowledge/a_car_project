<template>
  <router-view />
</template>

<script setup lang="ts">
// 根组件
</script>

<style>
#app {
  font-family: 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 'WenQuanYi Micro Hei', system-ui, -apple-system, sans-serif;
}
</style>
